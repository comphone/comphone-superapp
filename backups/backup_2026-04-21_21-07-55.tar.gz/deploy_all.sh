#!/bin/bash
set -euo pipefail

echo "🚀 COMPHONE FULL AUTO DEPLOY START"

DATE=$(date +"%Y-%m-%d_%H-%M-%S")
ROOT="/mnt/c/Users/Server/comphone-superapp"

cd "$ROOT" || { echo "❌ Cannot cd to $ROOT"; exit 1; }

# ========================
# 0. PRECHECK
# ========================
echo "🔍 PRECHECK..."

# Core files
MISSING=0
for f in pwa/ai_executor_runtime.js pwa/execution_lock.js pwa/approval_guard.js clasp-ready/Router.gs clasp-ready/Auth.gs; do
  if [ ! -f "$f" ]; then
    echo "❌ Missing core file: $f"
    MISSING=1
  fi
done
if [ "$MISSING" -eq 1 ]; then
  echo "❌ CORE FILE MISSING — ABORT"
  exit 1
fi
echo "✅ Core files OK"

# Git remote
if ! git remote get-url origin >/dev/null 2>&1; then
  echo "❌ Git remote not configured"
  exit 1
fi
echo "✅ Git remote OK"

# clasp config
if [ ! -f "clasp-ready/.clasp.json" ]; then
  echo "❌ .clasp.json missing"
  exit 1
fi
echo "✅ Clasp config OK"

# ========================
# 1. LOCAL BACKUP
# ========================
echo "💾 Creating local backup..."
mkdir -p backups
tar czf "backups/backup_$DATE.tar.gz" --exclude='node_modules' --exclude='.git' --exclude='*.tar.gz' .
echo "✅ Local backup: backups/backup_$DATE.tar.gz"

# ========================
# 2. GIT PUSH (MAIN)
# ========================
echo "📦 Pushing to GitHub..."
if git diff --cached --quiet && git diff --quiet; then
  echo "⚠️ No local changes to commit"
else
  git add .
  git commit -m "AUTO DEPLOY $DATE" || echo "⚠️ Commit skipped"
fi

if git push origin main; then
  echo "✅ GitHub push OK"
else
  echo "❌ Git push failed (check credentials)"
  exit 1
fi

# ========================
# 3. SYNC PRODUCTION BRANCH
# ========================
echo "🔄 Sync production branch..."
if git push origin main:production/v16-stable --force; then
  echo "✅ Production branch synced"
else
  echo "❌ Production branch sync failed"
  exit 1
fi

# ========================
# 4. DEPLOY GAS
# ========================
echo "☁️ Deploying to GAS..."
cd clasp-ready || { echo "❌ Cannot cd clasp-ready"; exit 1; }
if clasp push; then
  echo "✅ GAS deploy OK"
else
  echo "❌ GAS push failed (check clasp login)"
  exit 1
fi
cd ..

# ========================
# 5. GOOGLE DRIVE BACKUP (CALL GAS)
# ========================
echo "☁️ Trigger Drive backup..."
cd clasp-ready || exit 1
if clasp run backupToDrive 2>/dev/null; then
  echo "✅ Drive backup triggered"
else
  echo "⚠️ Drive backup skipped (clasp run failed)"
fi
cd ..

# ========================
# 6. VERIFY GITHUB PAGES
# ========================
echo "🔍 Verifying GitHub Pages..."
sleep 5
PAGE=$(curl -sL "https://comphone.github.io/comphone-superapp/pwa/dashboard_pc.html?nocache=$DATE" || true)

if echo "$PAGE" | grep -q "AI_EXECUTOR"; then
  echo "✅ Pages updated (AI_EXECUTOR detected)"
else
  echo "❌ Pages still old version (AI_EXECUTOR not found)"
fi

# ========================
# 7. VERIFY CORE FILES
# ========================
echo "🔍 Final core file check..."
[ -f "pwa/ai_executor_runtime.js" ] && echo "✅ AI_EXECUTOR exists" || echo "❌ Missing AI_EXECUTOR"
[ -f "pwa/execution_lock.js" ] && echo "✅ Execution Lock exists" || echo "❌ Missing Execution Lock"
[ -f "pwa/approval_guard.js" ] && echo "✅ Approval Guard exists" || echo "❌ Missing Approval Guard"

echo ""
echo "🎯 DEPLOY COMPLETE — $DATE"

# 🔐 CREDENTIALS & ACCESS KEYS — สำหรับ Agent ใหม่

> **⚠️ ไฟล์นี้เป็นความลับ ห้ามเปิดเผยต่อสาธารณะหรือ commit ลง GitHub โดยเด็ดขาด**

---

## 1. GitHub Access

| รายการ | ค่า |
|---|---|
| **Repository** | `https://github.com/comphone/comphone-superapp` |
| **Branch หลัก** | `main` |
| **GitHub Personal Access Token (PAT)** | `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` |
| **Git User Name** | `COMPHONE AI Dev` |
| **Git User Email** | `narinoutagit@gmail.com` |

**วิธีใช้ใน Agent (clone + push):**
```bash
git clone https://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@github.com/comphone/comphone-superapp.git
cd comphone-superapp
git config user.name "COMPHONE AI Dev"
git config user.email "narinoutagit@gmail.com"
```

---

## 2. Google Drive Access

| รายการ | ค่า |
|---|---|
| **วิธียืนยันตัวตน** | OAuth2 (refresh_token) |
| **Scope** | `https://www.googleapis.com/auth/drive` |
| **Client ID** | `732739758651-ldbsivb44ub1526hvrdtshcg6ncfcr9a.apps.googleusercontent.com` |
| **Client Secret** | `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` |
| **Refresh Token** | `1//04K5isR3QbzM1CgYIARAAGAQSNwF-L9IrVsfWWgxURGkOhAUPse3Gin4WSo2r6A-S9Vsg6ljmvxdE642JUbd4foQoppjjsaU86IQ` |
| **Token URI** | `https://oauth2.googleapis.com/token` |

**วิธีใช้ใน Python (อัปโหลดไฟล์ลง Drive):**
```python
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

creds = Credentials(
    token=None,
    refresh_token="1//04K5isR3QbzM1CgYIARAAGAQSNwF-L9IrVsfWWgxURGkOhAUPse3Gin4WSo2r6A-S9Vsg6ljmvxdE642JUbd4foQoppjjsaU86IQ",
    token_uri="https://oauth2.googleapis.com/token",
    client_id="732739758651-ldbsivb44ub1526hvrdtshcg6ncfcr9a.apps.googleusercontent.com",
    client_secret="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",
    scopes=["https://www.googleapis.com/auth/drive"]
)

service = build('drive', 'v3', credentials=creds)

# อัปโหลดไฟล์
file_metadata = {'name': 'COMPHONE_FINAL_HANDOVER_v1611.zip', 'parents': ['FOLDER_ID']}
media = MediaFileUpload('path/to/file.zip', mimetype='application/zip')
file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()
print(f"Uploaded: {file.get('id')}")
```

---

## 3. Google Apps Script (GAS) — clasp Access

| รายการ | ค่า |
|---|---|
| **GAS Script ID** | `1-aoCd5gXoo1dX4FjW62l8JknR3ZPiaf1W7YEmEdtq8gnRzSp4Hwj6043` |
| **clasp Client ID** | `1072944905499-vm2v2i5dvn0a0d2o4ca36i1vge8cvbn0.apps.googleusercontent.com` |
| **clasp Client Secret** | `v6V3fKV_zWU7iw1DrpO1rknX` |
| **clasp Refresh Token** | `1//047RbRVcyVbeaCgYIARAAGAQSNwF-L9Irjppbue6nvl22e9jmB8AT2O287s7eU4X2Trot8LBcjrv5F7IIapz_04XzqXJCg5BW4Nc` |
| **clasp Scope** | drive, script.projects, script.deployments, script.webapp.deploy, cloud-platform |

**วิธีตั้งค่า .clasprc.json ใน Agent ใหม่:**
```bash
cat > ~/.clasprc.json << 'EOF'
{
  "token": {
    "access_token": "",
    "refresh_token": "1//047RbRVcyVbeaCgYIARAAGAQSNwF-L9Irjppbue6nvl22e9jmB8AT2O287s7eU4X2Trot8LBcjrv5F7IIapz_04XzqXJCg5BW4Nc",
    "scope": "https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/script.projects https://www.googleapis.com/auth/script.deployments https://www.googleapis.com/auth/script.webapp.deploy https://www.googleapis.com/auth/cloud-platform",
    "token_type": "Bearer",
    "expiry_date": 9999999999999
  },
  "oauth2ClientSettings": {
    "clientId": "1072944905499-vm2v2i5dvn0a0d2o4ca36i1vge8cvbn0.apps.googleusercontent.com",
    "clientSecret": "v6V3fKV_zWU7iw1DrpO1rknX",
    "redirectUri": "http://localhost:8888"
  },
  "isLocalCreds": false
}
EOF
```

**วิธี push GAS ด้วย clasp:**
```bash
cd /path/to/github-clone/clasp-ready
clasp push
clasp deploy
```

---

## 4. OpenAI API (LLM Proxy)

| รายการ | ค่า |
|---|---|
| **API Key** | `sk-W5KT4JiPJZRqpkunmEP73y` |
| **Base URL** | `https://api.manus.im/api/llm-proxy/v1` |
| **Models ที่ใช้ได้** | `gpt-4.1-mini`, `gpt-4.1-nano`, `gemini-2.5-flash` |

**วิธีใช้ใน Python:**
```python
from openai import OpenAI
import os

client = OpenAI(
    api_key="sk-W5KT4JiPJZRqpkunmEP73y",
    base_url="https://api.manus.im/api/llm-proxy/v1"
)
```

---

## 5. สรุปการเข้าถึงที่ Agent ใหม่ทำได้ทันที

| ระบบ | สิทธิ์ | วิธีเข้าถึง |
|---|---|---|
| **GitHub** | Read + Write + Push | PAT Token ใน git remote URL |
| **Google Drive** | Read + Write (Upload/Download) | OAuth2 refresh_token |
| **Google Apps Script** | Push + Deploy | clasp + refresh_token |
| **OpenAI/LLM** | API Call | API Key + Base URL |

---

## 6. ไฟล์ที่ต้องสร้างใน Sandbox ของ Agent ใหม่

```bash
# 1. Clone GitHub repo
git clone https://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@github.com/comphone/comphone-superapp.git /home/ubuntu/github-clone

# 2. ตั้งค่า git identity
git config --global user.name "COMPHONE AI Dev"
git config --global user.email "narinoutagit@gmail.com"

# 3. ตั้งค่า Google Drive token
mkdir -p /home/ubuntu/.comphone
cat > /home/ubuntu/.comphone/token.json << 'EOF'
{"token": null, "refresh_token": "1//04K5isR3QbzM1CgYIARAAGAQSNwF-L9IrVsfWWgxURGkOhAUPse3Gin4WSo2r6A-S9Vsg6ljmvxdE642JUbd4foQoppjjsaU86IQ", "token_uri": "https://oauth2.googleapis.com/token", "client_id": "732739758651-ldbsivb44ub1526hvrdtshcg6ncfcr9a.apps.googleusercontent.com", "client_secret": "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", "scopes": ["https://www.googleapis.com/auth/drive"], "universe_domain": "googleapis.com"}
EOF

# 4. ตั้งค่า clasp
cat > ~/.clasprc.json << 'EOF'
{"token":{"access_token":"","refresh_token":"1//047RbRVcyVbeaCgYIARAAGAQSNwF-L9Irjppbue6nvl22e9jmB8AT2O287s7eU4X2Trot8LBcjrv5F7IIapz_04XzqXJCg5BW4Nc","scope":"https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/script.projects https://www.googleapis.com/auth/script.deployments https://www.googleapis.com/auth/script.webapp.deploy https://www.googleapis.com/auth/cloud-platform","token_type":"Bearer","expiry_date":9999999999999},"oauth2ClientSettings":{"clientId":"1072944905499-vm2v2i5dvn0a0d2o4ca36i1vge8cvbn0.apps.googleusercontent.com","clientSecret":"v6V3fKV_zWU7iw1DrpO1rknX","redirectUri":"http://localhost:8888"},"isLocalCreds":false}
EOF
```

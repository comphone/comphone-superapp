#!/bin/bash
# COMPHONE SUPER APP — FULL AUTO DEPLOY PIPELINE
# PHASE 23: Hardened Deploy Script
# RULES: No set -e on clasp, retry logic, timeout, verify

# set -e ใช้เฉพาะ pre-check ที่ critical จริง ๆ
# clasp push/run จะ handle แยกต่างหาก

exec >> deploy.log 2>&1

echo ""
echo "================================================================"
echo "🚀 COMPHONE FULL AUTO DEPLOY START — $(date)"
echo "================================================================"

DATE=$(date +"%Y-%m-%d_%H-%M-%S")
ROOT="/mnt/c/Users/Server/comphone-superapp"

cd "$ROOT" || { echo "❌ Cannot cd to $ROOT"; exit 1; }

# ========================
# RETRY HELPER
# ========================
retry() {
  local max=3
  local delay=2
  local n=1
  while [ $n -le $max ]; do
    echo "  [retry] Attempt $n/$max: $*"
    if "$@"; then
      return 0
    fi
    if [ $n -eq $max ]; then
      echo "  [retry] All $max attempts failed"
      return 1
    fi
    n=$((n + 1))
    sleep $delay
  done
}

# ========================
# 0. PRECHECK
# ========================
echo "🔍 PRECHECK..."

MISSING=0
for f in pwa/ai_executor_runtime.js pwa/execution_lock.js pwa/approval_guard.js clasp-ready/Router.gs clasp-ready/Auth.gs; do
  if [ ! -f "$f" ]; then
    echo "❌ Missing core file: $f"
    MISSING=1
  fi
done
if [ "$MISSING" -eq 1 ]; then
  echo "❌ CORE FILE MISSING — ABORT"
  exit 1
fi
echo "✅ Core files OK"

if ! git remote get-url origin >/dev/null 2>&1; then
  echo "❌ Git remote not configured"
  exit 1
fi
echo "✅ Git remote OK"

if [ ! -f "clasp-ready/.clasp.json" ]; then
  echo "❌ .clasp.json missing"
  exit 1
fi
echo "✅ Clasp config OK"

# ========================
# 1. LOCAL BACKUP
# ========================
echo "💾 Creating local backup..."
mkdir -p backups
BACKUP_FILE="backups/backup_$DATE.tar.gz"
tar czf "$BACKUP_FILE" --exclude='node_modules' --exclude='.git' --exclude='*.tar.gz' --exclude='backups' .
BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
echo "✅ Local backup: $BACKUP_FILE ($BACKUP_SIZE)"

# ========================
# 2. GIT PUSH (MAIN)
# ========================
echo "📦 Pushing to GitHub..."
if git diff --cached --quiet && git diff --quiet; then
  echo "⚠️ No local changes to commit"
else
  git add .
  git commit -m "AUTO DEPLOY $DATE" || echo "⚠️ Commit skipped"
fi

if retry git push origin main; then
  echo "✅ GitHub push OK"
else
  echo "❌ Git push failed after retries"
  exit 1
fi

# ========================
# 3. SYNC PRODUCTION BRANCH
# ========================
echo "🔄 Sync production branch..."
if retry git push origin main:production/v16-stable --force; then
  echo "✅ Production branch synced"
else
  echo "⚠️ Production branch sync failed (non-critical)"
fi

# ========================
# 4. DEPLOY GAS
# ========================
echo "☁️ Deploying to GAS..."
cd clasp-ready || { echo "❌ Cannot cd clasp-ready"; exit 1; }

# clasp push อาจ return non-zero ทั้งที่ success
# ใช้ capture output แล้ว grep verify แทน
echo "  → Running clasp push..."
CLASP_OUTPUT=$(clasp push 2>&1)
CLASP_EXIT=$?

echo "$CLASP_OUTPUT"

if echo "$CLASP_OUTPUT" | grep -q "Pushed"; then
  echo "✅ GAS push verified (output contains 'Pushed')"
  GAS_OK=1
elif [ $CLASP_EXIT -eq 0 ]; then
  echo "✅ GAS push exit 0"
  GAS_OK=1
else
  echo "⚠️ clasp exit = $CLASP_EXIT, output not verified. Retrying..."
  CLASP_OUTPUT=$(retry clasp push 2>&1)
  if echo "$CLASP_OUTPUT" | grep -q "Pushed"; then
    echo "✅ GAS push verified on retry"
    GAS_OK=1
  else
    echo "❌ GAS push failed after retry"
    GAS_OK=0
  fi
fi

cd "$ROOT"

# ========================
# 5. GOOGLE DRIVE BACKUP (CALL GAS)
# ========================
echo "☁️ Trigger Drive backup..."
cd clasp-ready || exit 1

# Run in background with timeout ไม่ให้ block deploy pipeline
echo "  → Starting clasp run backupToDrive (background)..."
clasp run backupToDrive > /tmp/clasp_backup.log 2>&1 &
BACKUP_PID=$!

TIMEOUT=120
SECONDS_WAITED=0
while kill -0 $BACKUP_PID 2>/dev/null; do
  if [ $SECONDS_WAITED -ge $TIMEOUT ]; then
    echo "⚠️ Backup timeout (${TIMEOUT}s) — killing process, continue deploy"
    kill -9 $BACKUP_PID 2>/dev/null
    break
  fi
  sleep 1
  SECONDS_WAITED=$((SECONDS_WAITED + 1))
done

# Check result
wait $BACKUP_PID 2>/dev/null
BACKUP_EXIT=$?
if [ -f /tmp/clasp_backup.log ] && grep -q "OK\|success" /tmp/clasp_backup.log 2>/dev/null; then
  echo "✅ Drive backup completed"
elif [ $BACKUP_EXIT -eq 0 ]; then
  echo "✅ Drive backup exit 0"
else
  echo "⚠️ Drive backup result unknown (exit=$BACKUP_EXIT, see /tmp/clasp_backup.log)"
fi

cd "$ROOT"

# ========================
# 6. VERIFY GITHUB PAGES
# ========================
echo "🔍 Verifying GitHub Pages..."
sleep 5

PAGE_URL="https://comphone.github.io/comphone-superapp/pwa/dashboard_pc.html?nocache=$DATE"
PAGE=$(curl -sL "$PAGE_URL" 2>/dev/null || true)

if echo "$PAGE" | grep -q "AI_EXECUTOR"; then
  echo "✅ Pages updated (AI_EXECUTOR detected)"
  PAGES_OK=1
else
  echo "⚠️ Pages not updated yet (cache delay possible)"
  PAGES_OK=0
fi

# Verify index.html too
INDEX_URL="https://comphone.github.io/comphone-superapp/pwa/index.html?nocache=$DATE"
INDEX=$(curl -sL "$INDEX_URL" 2>/dev/null || true)

if echo "$INDEX" | grep -q "ai_executor_runtime"; then
  echo "✅ index.html has ai_executor_runtime.js"
  INDEX_OK=1
else
  echo "⚠️ index.html may still be cached"
  INDEX_OK=0
fi

# ========================
# 7. VERIFY CORE FILES
# ========================
echo "🔍 Final core file check..."
[ -f "pwa/ai_executor_runtime.js" ] && echo "✅ AI_EXECUTOR exists" || echo "❌ Missing AI_EXECUTOR"
[ -f "pwa/execution_lock.js" ] && echo "✅ Execution Lock exists" || echo "❌ Missing Execution Lock"
[ -f "pwa/approval_guard.js" ] && echo "✅ Approval Guard exists" || echo "❌ Missing Approval Guard"

# ========================
# 8. FINAL REPORT
# ========================
echo ""
echo "================================================================"
echo "📊 DEPLOY REPORT — $DATE"
echo "================================================================"
echo "GitHub Push:        ✅"
echo "GAS Deploy:         $([ "$GAS_OK" = "1" ] && echo '✅' || echo '❌')"
echo "Drive Backup:       $([ -f /tmp/clasp_backup.log ] && echo '✅' || echo '⚠️')"
echo "Pages (dashboard):  $([ "$PAGES_OK" = "1" ] && echo '✅' || echo '⚠️')"
echo "Pages (index):      $([ "$INDEX_OK" = "1" ] && echo '✅' || echo '⚠️')"
echo "Local Backup:       $BACKUP_FILE ($BACKUP_SIZE)"
echo "================================================================"
echo "🎯 DEPLOY COMPLETE — $(date)"
echo "================================================================"
echo ""
